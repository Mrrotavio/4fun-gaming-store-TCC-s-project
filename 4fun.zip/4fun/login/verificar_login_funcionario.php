<?php
     //Criando as variaveis locais
     
     $botao = $_POST["botao"];
     $login = $_POST["login"];
     $senha = $_POST["senha"];
     
     //Verificando qual foi o botao clicado
     $senha = md5($senha);
     if($botao == "OK")
     {
               //Botao OK foi clicado

               //Verificando se os campos estão preenchidos

               if((empty($login)) && (empty($senha)))
               {
                   //Todos os dados devem ser preenchidos
?>
                   <script language='JavaScript'>
                           alert('Você deve preencher todos os dados!!!');
                           document.location.href="form_login_funcionario.html";
                   </script>
<?php
               }
               else if(empty($login))
               {

                    //Campo nickname deve ser preenchido
?>
                    <script language='JavaScript'>
                            alert('Você deve preencher o Campo Email!!');
                            document.location.href="form_login_funcionario.html";
                    </script>
<?php
               }
               else if(empty($senha))
               {

                    //Campo senha deve ser preenchido
?>
                    <script language='JavaScript'>
                            alert('Você deve preencher o Campo Senha!!');
                            document.location.href="form_login_funcionario.html";
                    </script>
<?php
               }
               else
               {
                    //Todos os campos foram preenchidos
                    
                   //Importando o arquivo de conexao

                   require("../conexao.php");

                   $consultar_emails = "SELECT * FROM $table_funcionario WHERE login = '$login'";
                   $resultado_consultar_emails = mysqli_query($conn,$consultar_emails);
                   $quantidade_registros_emails = mysqli_num_rows($resultado_consultar_emails);

                   //Verificando se foi encontrado algum registro

                   if($quantidade_registros_emails == 0)
                   {
                    //Email Não Encontrado
?>
                     <script language='javascript'>
                             alert("Email Inexistente!!!");
                             document.location.href="form_login_funcionario.html";
                     </script>
<?php
                   }
                   else
                   {
                    //Email Encontrado             

                       $consultar_logins = "SELECT * FROM $table_funcionario WHERE login = '$login' AND senha = '$senha'";
                       $resultado_consultar_logins = mysqli_query($conn,$consultar_logins);
                       $quantidade_registros_logins = mysqli_num_rows($resultado_consultar_logins);

                       //Verificando a quantidade de registros que foi retornado

                       if($quantidade_registros_logins == 0)
                       {
                        //Senha Inválida
?>
                        <script language='javascript'>
                                alert("Senha Inválida!!!");
                                document.location.href="form_login_funcionario.html";
                        </script>
<?php
                       }
                       else
                       {
                            //Email e Senha estão corretos
                            //Verificando se a situação do usuário está OK
                            
                            $vetor = mysqli_fetch_array($resultado_consultar_logins);
                            
                        
                                 //O usuário está OK e logado

                                //Inicializando uma sessao

                   		        session_start();

                   		        //Criando uma variavel de controle do sistema

                   		        //Registrando esta variavel no sistema
                                $id = $_SESSION['id'] = $vetor['id'];
                                $_SESSION["system_control"] = 1;
                                $_SESSION["login"] = $vetor['login'];
                                //Registrando a variavel de status no sistema

                                $_SESSION["cargo"] = $vetor['cargo'];
                                
                                //Registrando o login do usuário na sessão

                                $_SESSION['cod_login'] = $vetor['codigo'];
								
								$cargo = $_SESSION["cargo"];

                                //Verificando o tipo de login do usuário

                                if($cargo == A)
                                {
                                     //O usuário é um administrador                                     
                                     //Redirecionando para a Tela do administrador?>
                                     <script language='JavaScript'>
                                          document.location.href="../adm.php";
                                     </script>
							<?php
                                }
                                else if($cargo == TI)
                                {
                                    //O usuário é um funcionario
							?>
                                     <script language='JavaScript'>
                                          document.location.href="../ti.php";
                                     </script>
							<?php
								}
                            }
                       }
                   }
               }
     
?>
