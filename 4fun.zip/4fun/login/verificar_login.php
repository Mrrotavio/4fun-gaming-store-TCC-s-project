<?php
     //Criando as variaveis locais
     
     $botao = $_POST["botao"];
     $email = $_POST["email"];
     $senha = $_POST["senha"];
     
     //Verificando qual foi o botao clicado
     $senha = md5($senha);
     if($botao == "OK")
     {
               //Botao OK foi clicado

               //Verificando se os campos est�o preenchidos

               if((empty($email)) && (empty($senha)))
               {
                   //Todos os dados devem ser preenchidos
?>
                   <script language='JavaScript'>
                           alert('Voce deve preencher todos os dados!!!');
                           document.location.href="form_login_cliente.html";
                   </script>
<?php
               }
               else if(empty($email))
               {

                    //Campo nickname deve ser preenchido
?>
                    <script language='JavaScript'>
                            alert('Voce deve preencher o Campo Email!!');
                            document.location.href="form_login_cliente.html"
                    </script>
<?php
               }
               else if(empty($senha))
               {

                    //Campo senha deve ser preenchido
?>
                    <script language='JavaScript'>
                            alert('Voce deve preencher o Campo Senha!!');
                            document.location.href="form_login_cliente.html"
                    </script>
<?php
               }
               else
               {
                    //Todos os campos foram preenchidos
                    
                   //Importando o arquivo de conexao

                   require("../conexao.php");

                   $consultar_emails = "SELECT * FROM $table_cliente WHERE email = '$email'";
                   $resultado_consultar_emails = mysqli_query($conn,$consultar_emails);
                   $quantidade_registros_emails = mysqli_num_rows($resultado_consultar_emails);

                   //Verificando se foi encontrado algum registro

                   if($quantidade_registros_emails == 0)
                   {
                    //Email N�o Encontrado
?>
                     <script language='javascript'>
                             alert("Email Inexistente!!!");
                             document.location.href="form_login_cliente.html";
                     </script>
<?php
                   }
                   else
                   {
                    //Email Encontrado             

                       $consultar_logins = "SELECT * FROM $table_cliente WHERE email = '$email' AND senha = '$senha'";
                       $resultado_consultar_logins = mysqli_query($conn,$consultar_logins);
                       $quantidade_registros_logins = mysqli_num_rows($resultado_consultar_logins);

                       //Verificando a quantidade de registros que foi retornado

                       if($quantidade_registros_logins == 0)
                       {
                        //Senha Inv�lida
?>
                        <script language='javascript'>
                                alert("Senha Inv�lida!!!");
                                document.location.href="form_login_cliente.html";
                        </script>
<?php
                       }
                       else
                       {
                            //Email e Senha est�o corretos
                            //Verificando se a situa��o do usu�rio est� OK
                            
                            $vetor = mysqli_fetch_array($resultado_consultar_logins);

                                 //O usu�rio est� OK e logado

                                //Inicializando uma sessao

                   		        session_start();

                   		        //Criando uma variavel de controle do sistema

                   		        //Registrando esta variavel no sistema

                                $_SESSION["system_control"] = 1;

                                //Registrando a variavel de status no sistema
                                $_SESSION["status"] = 1;
                                //Registrando o login do usu�rio na sess�o
								
                                $_SESSION["email"] = $email;
                                //Verificando o tipo de login do usu�rio

                                $_SESSION["botao"] = $botao;


							?>
                                     <script language='JavaScript'>
                                          document.location.href="../loja/loja.php";
                                     </script>
							<?php		
                                
                            }
                       }
                   }
               }     
?>
