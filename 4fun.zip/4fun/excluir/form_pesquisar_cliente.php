<?php
    
    //Mantendo a sessão
    session_start();
    error_reporting(0);
    //Recuperando as variaveis da sessão
    $system_control = $_SESSION["system_control"];
    $cargo = $_SESSION["cargo"];
    $login = $_SESSION["login"];
    $id = $_SESSION["id"];
    //Verificando se o usuário realizou o login

    if(($system_control == 1)&&($cargo == 'A'))
    {
?>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
		<title>4FUN</title>
	</head> 
	<body>
		<h2>4FUN</h2><p>
		<table border=1>
			<tr>
				<td>
					<form method="post" action="excluir_cliente.php">
						Id do cliente: <input name="id" type=text size=30 maxlength=50><br>
						<input type=submit value=Enviar>
					</form>
				</td>	
			</tr>	
	</body>
</html>

<?php
    }
    else
    {
          //acesso negado
          //Finalizando a sessão
          session_destroy();
                 
?>
                        <script language='javascript'>
                                alert("Acesso Negado!!!");
                                document.location.href="../index.html";
                        </script>
<?php
        }
?>