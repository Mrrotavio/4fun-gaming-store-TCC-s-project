<?php	
	//conexao com o bd
	require('..\conexao.php');
		
	// Pegamos a palavra
	$id = $_POST['id'];

		$sql2 = mysqli_query($conn,"DELETE FROM $table_cliente WHERE `id`='$id'");
		
		echo"Apagado com Sucesso!";
	
?>
<p><a href="form_pesquisar_funcionario.html">Voltar</a>