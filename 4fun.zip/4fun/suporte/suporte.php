<?php
	//Importando a Conexão
	require('..\conexao.php');
	
	// Pegamos a palavra
	$nome = trim($_POST['nome']);
	$email = trim($_POST['email']);
	$mensagem = trim($_POST['mensagem']);
	
		mysqli_query($conn,"INSERT INTO ajuda(`nome`, `email`,`mensagem`) VALUES ('$nome','$email','$mensagem')");	
		echo "Sua reclamação foi enviada";		
?>
<p><a href="../index.html">Voltar</a>