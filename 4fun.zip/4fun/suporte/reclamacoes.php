<?php
    
    //Mantendo a sessão
    session_start();
    error_reporting(0);
    //Recuperando as variaveis da sessão
    $system_control = $_SESSION["system_control"];
    $cargo = $_SESSION["cargo"];
    $login = $_SESSION["login"];
    $id = $_SESSION["id"];
    //Verificando se o usuário realizou o login

    if(($system_control == 1)&&($cargo == 'A'))
    {
?>
        <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
          <html xmlns="http://www.w3.org/1999/xhtml">
              <head>
                  <link rel="stylesheet" href="../css/reset.css">
                  <link rel="stylesheet" href="../css/estilo.css">
                  <link rel="stylesheet" href="../css/suporte/reclamacao.css">
                  <link rel="shortcut icon" href="4FUN.png">	
                  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
                  <title>Loja-4FUN gaming store</title>
              </head> 
              <body>
                      <figure id="barra_navegacao">
                      <img src="../4FUN.png" alt="logo" width=150 height=150>
                    </figure>
                  <table>
                  
                  <ul class="tabela-de-produtos">
                      <?php
                              //Fazendo a conexao com o BD
                              require("../conexao.php");
          
                              //A variavel recebe uma instrução SQL   
                              $sql = "SELECT * FROM ajuda";
          
                              //Executando a SQL ou Mostrando a tela de erro caso não aconteça a conexão
                              $query = mysqli_query($conn,$sql) or die(mysqli_error());
                              
                              //Laço de repetição While que irá se repetir enquanto existir registros na variavel "$ln"
                              while($ln = mysqli_fetch_assoc($query))
                              {
                                  //Mostrando o valor da posição 'nome' do vetor "$ln"
                                  echo '<ul class="barra"><li class="nome-produto"><h2>'.$ln['nome'].'</h2></li> <br />';
                                  //Mostrando o valor da posição 'preco' do vetor "$ln"
                                  echo '<li class="preco-produto"><h2> '.$ln['email'].'</h2></li><br/>';
                                  //Mostrando o valor da posição 'imagem' do vetor "$ln"
                                  echo '<li><h2>'.$ln['mensagem'].'</h2></li></ul><br />';
                                  //Mostrando o valor da posição 'nome' do vetor "$ln"
                              
                              }
          
                      ?>	 
                  </ul>
                  </table>
              </body> 
          </html>
          <?php
    }
    else
    {
          //acesso negado
          //Finalizando a sessão
          session_destroy();
                 
?>
                        <script language='javascript'>
                                alert("Acesso Negado!!!");
                                document.location.href="../index.html";
                        </script>
<?php
        }
?>
