<?php
	//Importando a Conexão
	require('..\conexao.php');
	
	// Pegamos a palavra
	$nome = trim($_POST['nome']);
	$sobrenome = trim($_POST['sobrenome']);
	$estado = trim($_POST['estado']);
	$cidade = trim($_POST['cidade']);
	$bairro = trim($_POST['bairro']);
	$rua = trim($_POST['rua']);
	$n = trim($_POST['n']);
	$complemento = trim($_POST['complemento']);
	$cep1 = trim($_POST['cep1']);
	$cep2 = trim($_POST['cep2']);
	$email = trim($_POST['email']);
	$date = trim($_POST['data_nascimento']);
	$cpf = trim($_POST['cpf']);
	$ddd = trim($_POST['ddd']);
	$numero = trim($_POST['numero']);
	$senha = trim($_POST['senha']);	
	
	//concatenaçoes
	$cep = $cep1.$cep2; 
	$telefone = $ddd.$numero;
	function validateCpf($cpf)
{
     $cpf = str_replace(array('.','-'), '', $cpf);
	 if($cpf == "00000000000" || 
	    $cpf == "11111111111" || 
	    $cpf == "22222222222" || 
	    $cpf == "33333333333" || 
	    $cpf == "44444444444" || 
	    $cpf == "55555555555" || 
	    $cpf == "66666666666" || 
	    $cpf == "77777777777" || 
	    $cpf == "88888888888" || 
	    $cpf == "99999999999"):
          return false;
     else:
          for ($t = 9; $t < 11; $t++):
               for ($d = 0, $c = 0; $c < $t; $c++) $d += $cpf{$c} * (($t + 1) - $c);
                    $d = ((10 * $d) % 11) % 10;
                    if ($cpf{$c} != $d)
                         return false;
          endfor;
          return true;
     endif;
}

   	if (validateCpf($cpf)){
		   
	   

		$sql_2 = mysqli_query($conn,"SELECT * FROM $table_cliente WHERE `email` = '$email' OR `cpf` = '$cpf'");
		
		//Transformando o resultado em numeros
		$numero = mysqli_num_rows($sql_2);
		
		if($numero != 0)
		{
			echo "Existe um Cliente já cadastrado";
		}
		else
		{	
			$senha = md5($senha);
			// Inserindo os dados
			mysqli_query($conn,"INSERT INTO cliente(`nome`, `sobrenome`, `estado`,`cidade`,`bairro`,`rua`,`n`,`complemento`,`cep`,`data_nascimento`, `cpf`, `telefone`,`email`,`senha`) VALUES ('$nome','$sobrenome', '$estado','$cidade','$bairro','$rua','$n','$complemento','$cep','$date','$cpf',$telefone,'$email','$senha')");	
			echo "Cadastrado com Sucesso!";
		}
	   }
	   else
	   {
		?>
                        <script language='javascript'>
                                alert("CPF Invalido");
                                document.location.href="form_cadastro_cliente.php";
                        </script>
<?php
	   }

?>
                        <script language='javascript'>
                                alert("Cadastrado com sucesso");
                                document.location.href="../login/form_login_cliente.html";
                        </script>
<?php