<?php
    
    //Mantendo a sessão
    session_start();
    error_reporting(0);
    //Recuperando as variaveis da sessão
    $system_control = $_SESSION["system_control"];
    $cargo = $_SESSION["cargo"];
    $login = $_SESSION["login"];
    $id = $_SESSION["id"];
    //Verificando se o usuário realizou o login

    if(($system_control == 1)&&($cargo == 'A'))
    {
?>
<html>
	<head>
                <title>4FUN-Cadastro-produto</title>
                <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
                <link rel="stylesheet" type="text/css" href="../css/reset.css">
                <link rel="stylesheet" type="text/css" href="../css/estilo.css">
                <link rel="stylesheet" type="text/css" href="../css/cadastrar/formulario_cadastro_produto.css">
                <link rel="shortcut icon" href="..//4FUN.png">	
	</head> 
	<body>

        <figure id="barra_navegacao">
                <img class="foto" src="../4FUN.png" alt="logo" width=150 height=150>
        </figure>

		
         <table class="tabela_produto" border="1">
			<tr>
				<td>
		<form class="form_produto" enctype="multipart/form-data" method="post" action="cadastro_produto.php">
			Nome do Jogo: <input name="nome" type="text" size=30 maxlength=50 autofocus><br>
                        lançamento: <input name="lancamento" type="date" size=30 maxlength=50 autofocus><br>
                        preço: <input name="preco" type="text" size=30 maxlength=50 autofocus><br>
                        faixa_etaria:
                        <input type="radio" name="faixa_etaria" value="L">L
                        <input type="radio" name="faixa_etaria" value="10">10
                        <input type="radio" name="faixa_etaria" value="12">12
                        <input type="radio" name="faixa_etaria" value="14">14
                        <input type="radio" name="faixa_etaria" value="16">16
                        <input type="radio" name="faixa_etaria" value="18">18<br>
                        genero: <input name="genero" type="text" size=30 maxlength=50 autofocus><br>
                        plataforma: 
                        <input type="radio" name="plataforma" value="PC">PC 
                          <input type="radio" name="plataforma" value="XONE">XONE
                         <input type="radio" name="plataforma" value="PS4">PS4<br>
                        midia: 
                        <input type="radio" name="midia" value="F">Fisica
                        <input type="radio" name="midia" value="D">Digital<br>
                        imagem: <input name="arquivo" type="file" autofocus><br>
			<input class="botao_apertado botao_enviar_produto" type="submit" value="Enviar">
			<input class="botao_apertado botao_limpar_produto" type="reset" value="Limpar">
		</form>
				</td>	
			</tr>
        </table>
	</body>
</html>
<?php
    }
    else
    {
          //acesso negado
          //Finalizando a sessão
          session_destroy();
                 
?>
                        <script language='javascript'>
                                alert("Acesso Negado!!!");
                                document.location.href="../index.html";
                        </script>
<?php
        }
?>