<?php
    
    //Mantendo a sessão
    session_start();
    error_reporting(0);
    //Recuperando as variaveis da sessão
    $system_control = $_SESSION["system_control"];
    $cargo = $_SESSION["cargo"];
    $login = $_SESSION["login"];
    $id = $_SESSION["id"];
    //Verificando se o usuário realizou o login

    if(($system_control == 1)&&($cargo == 'A'))
    {
?>
<html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <title>4FUN-Cadastro-funcionario</title>
        <link rel="stylesheet" type="text/css" href="../css/reset.css">
        <link rel="stylesheet" type="text/css" href="../css/estilo.css">
        <link rel="stylesheet" type="text/css" href="../css/cadastrar/formulario_cadastro_funcionario.css">
        <link rel="shortcut icon" href="..//4FUN.png">
        <script>
         
         function verificaNumero(e){
             if(e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)){
                 return false;
             }   
         }
         $(document).ready(function(){
             $("#cpf").keypress(verificaNumero);
         });
         function FormataCpf(evt){
             vr = (navigator.appName == 'Netscape') ?evt.target.value : evt.srcElement.value;
         if(vr.length == 3) vr = vr+".";                    
         if(vr.length == 7) vr = vr+".";
         if(vr.length == 11) vr = vr+"-";

             return vr;
         
         }


     </script>   
    </head>
    <body>
        
            <figure id="barra_navegacao">
                <img class="foto" src="../4FUN.png" alt="logo" width=150 height=150>
            </figure>
        
            <table class="tabela_funcionario" border="1">
                <tr>
                    <td>
                        <form class="form_funcionario"  method="post" action="cadastro_funcionario.php">
                            Nome: <input name="nome" type="text" size=30 maxlength=50 autofocus required>
                            Sobrenome: <input name="sobrenome" type=text size=30 maxlength=50 autofocus required><br>
                            login <input name="login" type="text" size=30 maxlength="50"required><br>
                            Email <input name="email" type="email" size=30 maxlength="50" required><br>
                           
                            Data de Nascimento: <input type=date name="data_nascimento" size=30 maxlength=50 required><br>
                            CPF:
                            <input type="text" name="cpf" size="14" maxlength="14" onkeypress="this.value = FormataCpf(event)"><br>
                            Telefone: 
                            <input name="ddd" type=text size=3 maxlength=3 required>
                            <input name="numero" type=text size=10 maxlength=10 required><br>
                            cargo:
                                ADM <input type="radio" name="cargo" value="A">
                                 TI <input type="radio" name="cargo" value="TI"><br>
                            
                             Senha: <input type="password" name="senha" size=8 maxlength=50 required><br>
                            Estado: <input name="estado" type=text size=25 maxlength=25 required><br>
                            Cidade: <input name="cidade" type=text size=25 maxlength=25 required>
                            Bairro: <input name="bairro" type=text size=25 maxlength=25 required><br>
                            Rua: <input name="rua" type=text size=25 maxlength=25 required>
                            N: <input name="n" type=text size=4 maxlength=4 required><br>
                            Complemento: <input name="complemento" type=text size=50 maxlength=50 required><br>
                            CEP: <input name="cep1" type=text size=5 maxlength=5 required> - 
                                <input name="cep2" type=text size=3 maxlength=3 required><br>
                            <input class="botao_enviar_funcionario" type=submit value=Enviar>
                        </form>
                    </td>	
                </tr>	
            </table>
    </body>
</html>

<?php
    }
    else
    {
          //acesso negado
          //Finalizando a sessão
          session_destroy();
                 
?>
                        <script language='javascript'>
                                alert("Acesso Negado!!!");
                                document.location.href="../index.html";
                        </script>
<?php
        }
?>