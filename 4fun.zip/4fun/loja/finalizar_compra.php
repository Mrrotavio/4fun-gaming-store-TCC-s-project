<?php 
  $nome = $_POST['nome'];
  $preco = $_POST['preco']; 
  $imagem = $_POST['imagem']; 
  
    //Importando o arquivo de conexao
    require("conexao.php");
				
    $sql = "SELECT * FROM $table_produto WHERE nome = '$nome'";
    $consulta = mysqli_query($conn,$sql);
       
    $Linhas_consulta = mysql_num_rows($consulta);
    	
	if($Linhas_consulta == 0) {
		$query = "INSERT INTO $table_produto(`nome`, `preco` , `imagem`) VALUES ('$nome',$preco,'$imagem')";
		$insert = mysqli_query($conn,$query);
			
		if($insert)
		{
				echo"Usuário cadastrado com sucesso!";
		}
		else
		{
				echo"Não foi possível cadastrar esse usuário";
		}
	}
	else{
		echo"Nome de usuário já Cadastrado!";
	}       
  
?>