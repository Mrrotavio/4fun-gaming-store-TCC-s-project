<head>
		<title>4FUN-Carrinho</title>
        <link rel="stylesheet" type="text/css" href="../css/reset.css">
        <link rel="stylesheet" type="text/css" href="../css/estilo.css">
        <link rel="stylesheet" type="text/css" href="../css/loja/carrinho.css">
        <link rel="shortcut icon" href="../4FUN.png">	
</head>
<?php
	//Iniciando a Sess�o
    session_start();
    if(!isset($_SESSION['carrinho']))
	{
		//Caso o carrinho n�o estiver iniciado, o mesmo ser� criado
		$_SESSION['carrinho'] = array();
    }
       
    //Verifica se existe algo no atributo acao do metodo get     
    if(isset($_GET['acao']))
	{          
		//Verifica se o atributo 'acao' tem o valor 'add', ou melhor dizendo, � o m�todo de adicionar no carrinho um produto. 
		if($_GET['acao'] == 'add')
		{
			//intval tranforma o valor em int
			//a Variavel $id recebe o id do produto via m�todo GET
			$id = intval($_GET['id']);
			//Verifica se existe algum produto no carrinho j� com este ID
			if(!isset($_SESSION['carrinho'][$id]))
			{
				//N�o tem produto com este ID, ent�o � adicionado na sess�o
				//o Carrinho com o ID do produto e o valor 1
				$_SESSION['carrinho'][$id] = 1;
				echo "<script>top.location.href='carrinho.php';</script>"; 
				
			}
			else
			{
				//O Carrinho j� tem o produto cadastrado, ent�o ele vai
				//adicionar mais 1 produto.
				$_SESSION['carrinho'][$id] += 1;	
				echo "<script>top.location.href='carrinho.php';</script>"; 
			}
			
		}
		//Verifica se o atributo 'acao' tem o valor 'del', ou melhor dizendo, � o m�todo que remove um produto especifico do carrinho .	  
		//Remover produto do carrinho
		if($_GET['acao'] == 'del')
		{
			//intval tranforma o valor em int e armazena em uma variavel
			$id = intval($_GET['id']);
			//Verifica se existe o produto no carrinho
			if(isset($_SESSION['carrinho'][$id]))
			{
				//unset apaga a vari�vel que contem o ID do produto que quero remover
				unset($_SESSION['carrinho'][$id]);
				echo "<script>top.location.href='carrinho.php';</script>"; 
			}
		}     
    }
       
       
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<body>
	<table class="carrinho">
			<p class="margem">
		
				<tr class="tabela-carrinho">
					<th width="244">Produto</th>
					<th width="79">Quantidade</th>
					<th width="89">Pre&ccedil;o</th>
					<th width="100">SubTotal</th>
					<th width="64">Remover</th>
				</tr>
   
            <form action="print.php" method="post">  
                     
            <tr class="continuar-limpar-carrinho">
				<td colspan="4"><a class="continuar-apertado" href="loja.php">Continuar Comprando</a></td>
				<td><a class="limpar-apertado" href="limpar.php">Limpar Carrinho</a></td>
	
			</tr>
    
               <?php
					//Contando o numero de registros na sessão "carrinho"
                    if(count($_SESSION['carrinho']) == 0)
					{
						//Não há produtos no carrinho
						echo '<tr class="nao-produto-carrinho"><td colspan="5">Não há produto no carrinho</td></tr>';
                    }
					else
					{
						//Fazendo a conexao com o banco
                        require("../conexao.php");
						
						//Criando a variavel total e atribuindo o valor 0
						$total = 0;
						
						//foreach � um la�o de repeti��o que ir� repetir uma vez
						//para cada registro
                        foreach($_SESSION['carrinho'] as $id => $qtd)
						{
							//Atribuindo uma SQL para a variavel $sql
                            $sql   = "SELECT *  FROM produto WHERE id= '$id'";
                            //Executando a SQL
							$qr    = mysqli_query($conn,$sql) or die(mysqli_error());
                            //Criando um vetor com os registros encontrados
							$ln    = mysqli_fetch_assoc($qr);
                            
							//Atribuindo os valores do vetor para a variavel
                            $nome  = $ln['nome'];
                            $preco = number_format($ln['preco'], 2, ',', '.');
                            $sub   = number_format($ln['preco'] * $qtd, 2, ',', '.');
                               
                            $total += $ln['preco'] * $qtd;
                            
                           echo '<tr class="produto-carrinho">       
                                 <td>'.$nome.'</td>
                                 <td><input type="text" size="3" name="prod['.$id.']" value="'.$qtd.'" disabled/></td>
                                 <td>R$ '.$preco.'</td>                                
								<td>R$ '.$sub.'</td>
                                 <td><a href="?acao=del&id='.$id.'">Remove</a></td>
                              </tr>';
                        }
                           $total = number_format($total, 2, ',', '.');
                           echo '<tr class="total-carrinho">
                                    <td colspan="4">Total</td>
                                    <td>R$ '.$total.'</td>
                              </tr>';
                     }
					if (isset($ln)) 
					{
?>
						<input type='hidden' name='c_codigo' value=<?php echo "'$ln[nome]'"; ?>>
						<p>
						<input class="botao_apertado botao-compra-carrinho" type="submit" value="Finalizar Compra">
<?php
					}
?>				
     </body>
        </form>
</table>
 
</body>
</html>