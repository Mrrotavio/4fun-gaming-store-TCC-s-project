<head>
<title>4FUN-Confirmação Carrinho</title>
        <link rel="stylesheet" type="text/css" href="../css/reset.css">
        <link rel="stylesheet" type="text/css" href="../css/estilo.css">
        <link rel="stylesheet" type="text/css" href="../css/print.css">
        <link rel="shortcut icon" href="../4FUN.png">	
</head>
<?php 
    //Fazendo a Conexão com o Banco
	require("../conexao.php");
	
	//Iniciando a Sessão
	session_start();
	$system_control = $_SESSION["system_control"];
	$status = $_SESSION["status"];
	$email = $_SESSION["email"];
	if(($system_control == 1 AND $status == 1)){	
	//o foreach é um laço de repetição que funciona de acordo com o número
	//de registros que existirem no carrinho
    foreach($_SESSION['carrinho'] as $id => $qtd)
	{
		//A variavel recebe uma instrução sql
        $sql   = "SELECT * FROM produto WHERE id = '$id'";
		//Executa a SQL
		$qr    = mysqli_query($conn,$sql) or die(mysqli_error());
        //Cria um vetor do registro encontrado
		$ln    = mysqli_fetch_assoc($qr);
		//Armazenando o nome em uma variável					  
		$nome  = $ln['nome'];
		
		//Imprime os atributos do filme(ID) selecionado											

		echo "<div class='confirmar-compra'>";
			echo 	"<h1>Nome do Produto: $nome</h1><br>"; 

			echo 	"<h1>Quantidade: $qtd</h1><br>";

			echo 	"<h1>ID do Produto: $id</h1><br>";

			echo 	"<h1>Compra concluida com sucesso</h1><br>";
		echo "</div>";

								  
		$sqlpedido  ="INSERT INTO pedido(`id_produto`,`quantidade`) VALUES ($id, $qtd)";
		$resultado = mysqli_query($conn,$sqlpedido);    
	}
}else{
	?>
                        <script language='javascript'>
                                alert("Acesso Negado!!!");
                                document.location.href="../login/form_login_cliente.html";
                        </script>
<?php
}
?>