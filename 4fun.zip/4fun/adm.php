<?php
    
    //Mantendo a sessão
    session_start();
    error_reporting(0);
    //Recuperando as variaveis da sessão
    $system_control = $_SESSION["system_control"];
    $cargo = $_SESSION["cargo"];
    $login = $_SESSION["login"];
    $id = $_SESSION["id"];
    //Verificando se o usuário realizou o login

    if(($system_control == 1)&&($cargo == 'A'))
    {
?>
<html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <title>4FUN-ADM</title>
        <link rel="stylesheet" type="text/css" href="css/reset.css">
        <link rel="stylesheet" type="text/css" href="css/estilo.css">
        <link rel="stylesheet" type="text/css" href="css/funcionario/adm.css">
        <link rel="shortcut icon" href="4FUN.png">	
    </head>
    <body>
        
        <figure id="barra_navegacao">
           <img src="4FUN.png" alt="logo" width=150 height=150>
           <?php echo "<h1 class='nav-email'>$login</h1>";?>
           <a class="nav-sair" href='login/logout_funcionario.php'>Sair</a>
           <a class="nav-editar" href='alterar/resultado_alterar_funcionario.php'>Editar perfil</a>
        </figure>
        
        <main class="principal">
			<h1 class="site_titulo">ADM</h1><br><br>
            <article class="artigo cadastrar-produto">
                <h1 class="produto_titulo">cadastrar produto</h1>
                <p class="produto_paragrafo">cadastre o produto aqui</p>
                <a class="botao_apertado produto_botao-acesso" href="cadastro/form_cadastrar_produto.php">cadastrar produtos</a>
            </article> 
            <article class="artigo alterar-produto">
                <h1 class="produto_titulo">Alterar produto</h1>
                <p class="produto_paragrafo">Altere o produto aqui</p>
                <a class="botao_apertado produto_botao-acesso" href="alterar/form_pesquisar_produto.php">alterar produtos</a>
            </article>
            <article class="artigo apagar-produto">
                <h1 class="produto_titulo">Apagar produto</h1>
                <p class="produto_paragrafo">apague o produto aqui</p>
                <a class="botao_apertado produto_botao-acesso" href="excluir/form_pesquisar_produto.php">apagar produtos</a>
            </article>  
			<article class="artigo cadastrar-funcionario">
                <h1 class="funcionario_titulo">cadastrar funcionario</h1>
                <p class="funcionario_paragrafo">cadastre o funcionario aqui</p>
                <a class="botao_apertado funcionario_botao-acesso" href="cadastro/form_cadastro_funcionario.php">cadastrar funcionario</a>
            </article>
            <article class="artigo alterar-funcionario">
                <h1 class="funcionario_titulo">Alterar funcionario</h1>
                <p class="funcionario_paragrafo">Altere o funcionario aqui</p>
                <a class="botao_apertado funcionario_botao-acesso" href="alterar/form_pesquisar_funcionario.php">alterar funcionario</a>
            </article> 
            <article class="artigo apagar-funcionario">
                <h1 class="funcionario_titulo">Apagar funcionario</h1>
                <p class="funcionario_paragrafo">Apague o funcionario aqui</p>
                <a class="botao_apertado funcionario_botao-acesso" href="excluir/form_pesquisar_funcionario.php">apagar funcionario</a>
            </article>  
            <article class="artigo reclamacoes-cliente">
                <h1 class="reclamacoes_titulo">Reclamações dos clientes</h1>
                <p class="reclamacoes_paragrafo">Veja aqui a reclamação ou duvida dos clientes</p>
                <a class="botao_apertado reclamacoes_botao-acesso" href="suporte/reclamacoes.php">reclamacoes</a>
            </article> 
            <article class="artigo pedidos-cliente">
                <h1 class="pedidos_titulo">Pedidos dos clientes</h1>
                <p class="pedidos_paragrafo">Veja aqui os pedidos dos clientes</p>
                <a class="botao_apertado pedidos_botao-acesso" href="loja/pedidos.php">pedidos</a>
            </article>              
        </main>       
    </body>
</html>
<?php
    }
    else
    {
          //acesso negado
          //Finalizando a sessão
          session_destroy();
                 
?>
                        <script language='javascript'>
                                alert("Acesso Negado!!!");
                                document.location.href="login/form_login_funcionario.html";
                        </script>
<?php
        }
?>