<?php
    
    //Mantendo a sessão
    session_start();
    error_reporting(0);
    //Recuperando as variaveis da sessão
    $system_control = $_SESSION["system_control"];
    $cargo = $_SESSION["cargo"];
    $login = $_SESSION["login"];
    $id = $_SESSION["id"];
    //Verificando se o usuário realizou o login

    if(($system_control == 1)&&($cargo == 'TI'))
    {
?>
<html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <title>4FUN-TI</title>
        <link rel="stylesheet" type="text/css" href="css/reset.css">
        <link rel="stylesheet" type="text/css" href="css/estilo.css">
        <link rel="stylesheet" type="text/css" href="css/funcionario/ti.css">
        <link rel="shortcut icon" href="4FUN.png">	
    </head>
    <body>
        
        <figure id="barra_navegacao">
           <img src="4FUN.png" alt="logo" width=150 height=150>
            <link rel="shortcut icon" href="4FUN.png">	
            <?php echo "<h1 class='nav-email'>$login</h1>";?>
           <a class="nav-sair" href='login/logout_funcionario.php'>Sair</a>
           <a class="nav-editar" href='alterar/resultado_alterar_funcionario.php'>Editar perfil</a>
        </figure>
        
           <main class="principal">
			<h1 class="ti-titulo">TI</h1>
            <article class="artigo texto-loja">
                <h1 class="loja_titulo">Codigo no GoogleDrive</h1>
                <p class="loja_paragrafo">Ajude-nos </p>
                <a class="botao_apertado loja_botao-acesso" href="https://drive.google.com/file/d/1ZhZrmQCMhIPDXAFS8GeHBzLrGgda2dhm/view?usp=sharing">Arquivos</a>
            </article>           

		</main>
       
    </body>
</html>
<?php
    }
    else
    {
          //acesso negado
          //Finalizando a sessão
          session_destroy();
                 
?>
                        <script language='javascript'>
                                alert("Acesso Negado!!!");
                                document.location.href="login.html";
                        </script>
<?php
        }
?>