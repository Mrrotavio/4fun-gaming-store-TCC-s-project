<?php
	require('..\conexao.php');
	session_start();
	// Pegamos a palavra
    $email = $_SESSION["email"];
    
    $sql = mysqli_query($conn,"SELECT * FROM $table_cliente WHERE `email` = '$email'");
	
	//Transformando o resultado em numeros
	$numero = mysqli_num_rows($sql);
	
	//Transformando o resultado em vetor
	$vetor_funcionario = mysqli_fetch_array($sql);

$senha = $_POST['senha'];
$senha = md5($senha);

if($senha == $vetor_funcionario['senha']){
	?>
	<script language='javascript'>
	alert("Senha correta");
	</script>
	<head>
					<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
				<link rel="stylesheet" href="../css/reset.css">
				<link rel="stylesheet" href="../css/estilo.css">
        		<link rel="stylesheet" href="../css/alterar/alterar.css">
				<link rel="stylesheet" href="../css/alterar/tabela_alterar.css">
				<link rel="shortcut icon" href="../4FUN.png">	
				<title>4FUN</title>
</head>
<body>
	<form class="tabela-alterar" method="post" action="confirmar_alterar_senha_cliente.php">
	Altere a sua senha: <input name="senha" type=password size=25 maxlength=25><br>
	<input type="hidden" name="id" value="<?php echo $vetor_funcionario['id'];?>">
	<input type=submit onpress value=Enviar>
							</form>
</body>	
	<?php

}
else
{	
	?>	
	<script language='javascript'>
alert("Senha incorreta");
	</script>
	<?php
}	
