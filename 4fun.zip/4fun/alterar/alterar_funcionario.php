<?php	
	//conexao com o bd
	require('..\conexao.php');
	session_start();
	// Pegamos a palavra

	$login = $_SESSION["login"];
	$cargo = $_SESSION["cargo"];	
	// Pegamos a palavra
	$id = $_POST['id'];
	$nome = $_POST['nome'];
	$login = $_POST['login']; 
	$sobrenome = $_POST['sobrenome'];
	$data_nascimento = $_POST['data_nascimento'];
	$telefone = $_POST['telefone'];
	$estado = $_POST['estado'];
	$cidade = $_POST['cidade'];
	$bairro = $_POST['bairro'];
	$rua = $_POST['rua'];
	$n = $_POST['n'];
	$complemento = $_POST['complemento'];
	$cep = $_POST['cep'];
	$cpf = $_POST['cpf'];
	$email = $_POST['email'];
	//Procurando o produto solicitado
	$sql = mysqli_query($conn,"SELECT FROM $table_funcionario `nome`='$nome',`sobrenome`='$sobrenome',`login`='$login',`cpf`= '$cpf',`data_nascimento`='$data_nascimento',`telefone` ='$telefone',`estado`='$estado',`cidade` ='$cidade',`bairro`='$bairro',`rua`='$rua',`n`='$n',`complemento`='$complemento',`cep`='$cep',`email`='$email' WHERE `id`='$id'");
	
	//Transformando o resultado em numeros
	$numero = mysqli_num_rows($sql);
		
	if($numero != 0)
	{
		echo "Nome existente";
	}
	else
	{	
		$senha = md5($senha);
		//Atualizando a tabela
		$sql2 = mysqli_query($conn,"UPDATE $table_funcionario SET `nome`='$nome',`sobrenome`='$sobrenome',`login`='$login',`cpf`='$cpf',`data_nascimento`='$data_nascimento',`telefone`='$telefone',`estado`='$estado',`cidade`='$cidade',`bairro`='$bairro',`rua`='$rua',`n`='$n',`complemento`='$complemento',`cep`='$cep',`email`='$email' WHERE `id`='$id'");
    if(($cargo == 'A'))
    {
	?>
		<script language='javascript'>
		alert("Alteracao feita com sucesso");
		document.location.href="../adm.php";
		</script>
	<?php
	}else{
		?>
		<script language='javascript'>
		alert("Alteracao feita com sucesso");
		document.location.href="../ti.php";
		</script>
	<?php
	}
		
	}		
?>
