   <html>
			<head>
				<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
				<link rel="stylesheet" href="../css/reset.css">
				<link rel="stylesheet" href="../css/estilo.css">
        		<link rel="stylesheet" href="../css/alterar/alterar.css">
				<link rel="stylesheet" href="../css/alterar/tabela_alterar.css">
				<link rel="shortcut icon" href="../4FUN.png">	
				<title>4FUN</title>
			</head> 
			<body>
				<table class="tabela-alterar-usu">
					<tr>
						<td>
							<form class="tabela-alterar" method="post" action="alterar_senha_funcionario.php">
								
                          Digite sua senha<input type="password" name="senha" size=8 maxlength=50><br>
						  <input type="hidden" name="id" value="<?php echo $vetor_funcionario['id'];?>">
								<input type=submit onpress value=Enviar>
							</form>
						</td>	
					</tr>	
				</table>	
			</body>
		</html>
<p><a class="voltar" href="../loja/loja.php">Voltar</a>