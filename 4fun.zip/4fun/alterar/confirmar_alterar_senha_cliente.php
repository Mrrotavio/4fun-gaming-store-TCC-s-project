<?php
	require('..\conexao.php');
	session_start();
	// Pegamos a palavra
    $email = $_SESSION["email"];
    
    $sql = mysqli_query($conn,"SELECT * FROM $table_cliente WHERE `email` = '$email'");
	
	//Transformando o resultado em numeros
	$numero = mysqli_num_rows($sql);
	
	//Transformando o resultado em vetor
	$vetor_funcionario = mysqli_fetch_array($sql);
$id = $_POST["id"];	
$senha = $_POST['senha'];
$senha = md5($senha);

$sql = mysqli_query($conn,"SELECT from $table_cliente `senha` = '$senha' WHERE `id` = '$id'");
$sql2 = mysqli_query($conn,"UPDATE $table_cliente SET `senha` = '$senha' WHERE `id` = '$id'");
?>
	
	<script language='javascript'>
alert("Senha alterada com sucesso");
document.location.href="../loja/loja.php";
	</script>
	<?php