<?php	
	//conexao com o bd
	require('..\conexao.php');
	session_start();
	$email = $_SESSION["email"];
	$id = $_POST["id"];	
	// Pegamos a palavra
	
	
	$nome = $_POST['nome'];
	$sobrenome = $_POST['sobrenome'];
	$data_nascimento = $_POST['data_nascimento'];
	$telefone = $_POST['telefone'];
	$estado = $_POST['estado'];
	$cidade = $_POST['cidade'];
	$bairro = $_POST['bairro'];
	$rua = $_POST['rua'];
	$n = $_POST['n'];
	$complemento = $_POST['complemento'];
	$cep = $_POST['cep'];
	$cpf = $_POST['cpf'];
	$email = $_POST['email'];
	//Procurando o produto solicitado
	$sql = mysqli_query($conn,"SELECT from $table_cliente `nome`='$nome', `sobrenome`='$sobrenome', `email`='$email', `estado`='$estado', `cidade`='$cidade', `bairro`='$bairro', `rua`='$rua', `n`='$n', `complemento`='$complemento', `cep`='$cep', `telefone`='$telefone', `data_nascimento`='$data_nascimento', `cpf`='$cpf' WHERE `id` = '$id'");
	
	//Transformando o resultado em numeros
	$numero = mysqli_num_rows($sql);
		
	if($numero != 0)
	{
		echo "Nome existente";
	}
	else
	{	
		$senha = md5($senha);
		//Atualizando a tabela
		$sql2 = mysqli_query($conn,"UPDATE $table_cliente SET `nome`='$nome', `sobrenome`='$sobrenome', `email`='$email', `estado`='$estado', `cidade`='$cidade', `bairro`='$bairro', `rua`='$rua', `n`='$n', `complemento`='$complemento', `cep`='$cep', `telefone`='$telefone', `data_nascimento`='$data_nascimento', `cpf`='$cpf' WHERE `id` = '$id'");
		
		echo"Atualizado com Sucesso!";
	}		
?>
	
		<script language='javascript'>
		alert("Alteracao feita com sucesso");
		document.location.href="../loja/loja.php";
		</script>
	