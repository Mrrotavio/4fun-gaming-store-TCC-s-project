<?php
	//Importando a Conexão
	require('..\conexao.php');
	session_start();
	// Pegamos a palavra

	$login = $_SESSION["login"];
	$cargo = $_SESSION["cargo"];
	//Procurando o produto solicitado
	$sql = mysqli_query($conn,"SELECT * FROM $table_funcionario WHERE `login` = '$login'");
	
	//Transformando o resultado em numeros
	$numero = mysqli_num_rows($sql);
	
	//Transformando o resultado em vetor
	$vetor_funcionario = mysqli_fetch_array($sql);
		
	if($numero != 0)
	{
?>
		<html>
			<head>
			<meta charset="UTF-8">
		<title>4FUN-Cadastro-funcionario</title>
		<link rel="stylesheet" href="../css/reset.css">
		<link rel="stylesheet" href="../css/estilo.css">
        <link rel="stylesheet" href="../css/alterar/alterar.css">
		<link rel="stylesheet" href="../css/alterar/tabela_alterar.css">
        <link rel="shortcut icon" href="../4FUN.png">
			</head> 
			<body>
				<table class="tabela-alterar-usu">
					<tr>
						<td>
							<form class="tabela-alterar" method="post" action="alterar_funcionario.php">
								Nome do funcionario: <input name="nome" value="<?php echo $vetor_funcionario['nome'];?>" type=text size=25 maxlength=25><br>
								Nome do funcionario: <input name="sobrenome" value="<?php echo $vetor_funcionario['sobrenome'];?>" type=text size=25 maxlength=25><br>
								Login do funcionario: <input name="login" value="<?php echo $vetor_funcionario['login'];?>" type=text size=25 maxlength=25><br>	
								Data de nascimento: <input type=date name="data_nascimento" value="<?php echo $vetor_funcionario['data_nascimento'];?>" type=text size=25 maxlength=25><br>
								Telefone do funcionario: <input name="telefone" value="<?php echo $vetor_funcionario['telefone'];?>" type=text size=13 maxlength=13 required><br>
								Estado do funcionario: <input class="endereco_cliente" name="estado" value="<?php echo $vetor_funcionario['estado'];?>" type=text size=25 maxlength=25><br>
								Cidade do funcionario: <input class="endereco_cliente" name="cidade" value="<?php echo $vetor_funcionario['cidade'];?>" type=text size=25 maxlength=25>
								Bairro do funcionario: <input class="endereco_cliente" name="bairro" value="<?php echo $vetor_funcionario['bairro'];?>" type=text size=25 maxlength=25><br>
								Rua do funcionario: <input class="endereco_cliente" name="rua" value="<?php echo $vetor_funcionario['rua'];?>" type=text size=25 maxlength=25>
								N do funcionario: <input class="endereco_cliente" name="n" value="<?php echo $vetor_funcionario['n'];?>" type=text size=4 maxlength=4><br>
								Complemento do funcionario: <input class="endereco_cliente" name="complemento" value="<?php echo $vetor_funcionario['complemento'];?>" type=text size=25 maxlength=25><br>
								CEP do funcionario: <input class="endereco_cliente" name="cep" value="<?php echo $vetor_funcionario['cep'];?>" type=text size=11 maxlength=11><br>
								CPF do funcionario: <input class="endereco_cliente" name="cpf" value="<?php echo $vetor_funcionario['cpf'];?>" type=text size=14 maxlength=20><br>
								Email do funcionario: <input name="email" value="<?php echo $vetor_funcionario['email'];?>" type=email size=25 maxlength=25><br>
								<input type="hidden" name="id" value="<?php echo $vetor_funcionario['id'];?>">
								<input class="botao-alterar" type=submit value=Enviar>
								<a class="botao-alterar-senha" href="form_alterar_senha_funcionario.php">Alterar Senha</a><br>
							</form>
						</td>	
					</tr>	
				</table>	
			</body>
		</html>
<?php
	}
	else
	{		
		echo "Cliente Inexistente";
	}		

if($cargo =='A'){
?>
	<p><a class="botao-apertado voltar" href="../adm.php">Voltar</a>
<?php
}else{
?>
	<p><a class="botao-apertado voltar" href="../ti.php">Voltar</a>
<?php
}
?>