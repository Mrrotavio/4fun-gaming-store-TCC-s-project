<?php
	//Importando a Conexão
	require('..\conexao.php');
	session_start();
	// Pegamos a palavra
	$email = $_SESSION["email"];	
	
	//Procurando o produto solicitado
	$sql = mysqli_query($conn,"SELECT * FROM $table_cliente WHERE `email` = '$email'");
	
	//Transformando o resultado em numeros
	$numero = mysqli_num_rows($sql);
	
	//Transformando o resultado em vetor
	$vetor_funcionario = mysqli_fetch_array($sql);
		
	if($numero != 0)
	{
?>
		
		<html>
			<head>
				<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
				<link rel="stylesheet" href="../css/reset.css">
				<link rel="stylesheet" href="../css/estilo.css">
        		<link rel="stylesheet" href="../css/alterar/alterar.css">
				<link rel="stylesheet" href="../css/alterar/tabela_alterar.css">
				<link rel="shortcut icon" href="../4FUN.png">	
				<title>4FUN</title>
			</head> 
			<body>
				<table class="tabela-alterar-usu">
					<tr>
						<td>
							<form class="tabela-alterar" method="post" action="alterar_cliente.php">
								
								Nome do cliente: <input class="nome_cliente" name="nome" value="<?php echo $vetor_funcionario['nome'];?>" type=text size=50 maxlength=50><br>
								Sobrenome do cliente: <input class="nome_cliente" name="sobrenome" value="<?php echo $vetor_funcionario['sobrenome'];?>" type=text size=50 maxlength=50><br>
								Data de nascimento: <input class="data_cliente" type=date name="data_nascimento" value="<?php echo $vetor_funcionario['data_nascimento'];?>" type=text size=50 maxlength=50><br>
								Telefone do cliente: <input class="telefone_cliente" name="telefone" value="<?php echo $vetor_funcionario['telefone'];?>" type=text size=13 maxlength=13 required><br>
								Estado do cliente: <input class="endereco_cliente" name="estado" value="<?php echo $vetor_funcionario['estado'];?>" type=text size=50 maxlength=50><br>
								Cidade do cliente: <input class="endereco_cliente" name="cidade" value="<?php echo $vetor_funcionario['cidade'];?>" type=text size=50 maxlength=50><br>
								Bairro do cliente: <input class="endereco_cliente" name="bairro" value="<?php echo $vetor_funcionario['bairro'];?>" type=text size=50 maxlength=50><br>
								Rua do cliente: <input class="endereco_cliente" name="rua" value="<?php echo $vetor_funcionario['rua'];?>" type=text size=50 maxlength=50><br>
								N do cliente: <input class="endereco_cliente" name="n" value="<?php echo $vetor_funcionario['n'];?>" type=text size=50 maxlength=50><br>
								Complemento do cliente: <input class="endereco_cliente" name="complemento" value="<?php echo $vetor_funcionario['complemento'];?>" type=text size=50 maxlength=50><br>
								CEP do cliente: <input class="endereco_cliente" name="cep" value="<?php echo $vetor_funcionario['cep'];?>" type=text size=50 maxlength=50><br>
								CPF do cliente: <input class="endereco_cliente" name="cpf" value="<?php echo $vetor_funcionario['cpf'];?>" type=text size=50 maxlength=50><br>
								Email do cliente: <input class="email_cliente" name="email" value="<?php echo $vetor_funcionario['email'];?>" type=text size=50 maxlength=50><br>
								<input type="hidden" name="id" value="<?php echo $vetor_funcionario['id'];?>">
								<input type=submit class="botao-alterar" value=Enviar>
								<a class="botao-alterar-senha" href="form_alterar_senha_cliente.php">Alterar Senha</a><br>
							</form>
						</td>	
					</tr>	
				</table>	
			</body>
		</html>
<?php
	}
	else
	{		
		echo "Cliente Inexistente";
	}		
?>
<p><a class="voltar" href="../loja/loja.php">Voltar</a>