<?php
    
    //Mantendo a sessão
    session_start();
    error_reporting(0);
    //Recuperando as variaveis da sessão
    $system_control = $_SESSION["system_control"];
    $cargo = $_SESSION["cargo"];
    $login = $_SESSION["login"];
    $id = $_SESSION["id"];
    //Verificando se o usuário realizou o login

    if(($system_control == 1)&&($cargo == 'A'))
    {
?>
<html>
	<head>
			<link rel="stylesheet" type="text/css" href="../css/reset.css">
				<link rel="stylesheet" type="text/css" href="../css/estilo.css">
				<link rel="stylesheet" type="text/css" href="../css/alterar/formulario_alterar_produto.css">
				<link rel="shortcut icon" href="..//4FUN.png">	
			</head>
			<body>
				
					<figure id="barra_navegacao">
							<title>4FUN</title>
						<img class="foto" src="../4FUN.png" alt="logo" width=150 height=150>
						<link rel="shortcut icon" href="..//4FUN.png">
					</figure>
				<table class="tabela-id-alterar">
			<tr>
				<td>
					<form method="post" action="resultado_alterar_cliente.php">
						Id do cliente: <input name="id" type=text size=30 maxlength=50><br>
						<input class="botao_apertado botao-entrar" type=submit value=Enviar>
					</form>
				</td>	
			</tr>	
	</body>
</html>
<?php
    }
    else
    {
          //acesso negado
          //Finalizando a sessão
          session_destroy();
                 
?>
                        <script language='javascript'>
                                alert("Acesso Negado!!!");
                                document.location.href="../index.html";
                        </script>
<?php
        }
?>