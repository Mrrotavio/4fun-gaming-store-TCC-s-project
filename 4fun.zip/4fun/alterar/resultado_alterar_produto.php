<?php
	//Importando a Conexão
	require('..\conexao.php');
	
	// Pegamos a palavra
	$id = $_POST['id'];	
	
	//Procurando o produto solicitado
	$sql = mysqli_query($conn,"SELECT * FROM $table_produto WHERE `id` = '$id'");
	
	//Transformando o resultado em numeros
	$numero = mysqli_num_rows($sql);
	
	//Transformando o resultado em vetor
	$vetor_funcionario = mysqli_fetch_array($sql);
		
	if($numero != 0)
	{
?>
		<html>
			<head>
				<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
				<link rel="shortcut icon" href="../4FUN.png">	
				<title>4FUN</title>
			</head> 
			<body>
				<h2>4FUN</h2><p>
				<table border=1>
					<tr>
						<td>
							<form method="post" action="alterar_produto.php">
								<?php echo $id ?><br>
								Nome do jogo: <input name="nome" value="<?php echo $vetor_funcionario['nome'];?>" type=text size=50 maxlength=50><br>
								lancamento do jogo: <input name="lancamento" value="<?php echo $vetor_funcionario['lancamento'];?>" type=date size=50 maxlength=50><br>
								Preco do jogo: <input name="preco" value="<?php echo $vetor_funcionario['preco'];?>" type=text size=50 maxlength=50><br>
								Faixa Etaria: 
								L <input type="radio" name="faixa_etaria" value="L">
                         			10 <input type="radio" name="faixa_etaria" value="10">
                       			 12 <input type="radio" name="faixa_etaria" value="12">
                        			 14<input type="radio" name="faixa_etaria" value="14">
                        			16 <input type="radio" name="faixa_etaria" value="16">
                        			 18<input type="radio" name="faixa_etaria" value="18"><br>
								Genero do jogo: <input name="genero" value="<?php echo $vetor_funcionario['genero'];?>" type=text size=50 maxlength=50 required><br>
								plataforma: 
                        		PC <input type="radio" name="plataforma" value="PC">
                         			XONE <input type="radio" name="plataforma" value="XONE">
                        		PS4 <input type="radio" name="plataforma" value="PS4"><br>
                        		midia: 
                        		Fisica<input type="radio" name="midia" value="F">
                        		Digital<input type="radio" name="midia" value="D"><br>
								Imagem do jogo: <input name="imagem" value="<?php echo $vetor_funcionario['imagem'];?>" type=text size=50 maxlength=50><br>
								<input type="hidden" name="id" value="<?php echo $vetor_funcionario['id'];?>">
								<input type=submit value=Enviar>
							</form>
						</td>	
					</tr>	
				</table>	
			</body>
		</html>
<?php
	}
	else
	{		
		echo "Cliente Inexistente";
	}		
?>
<p><a href="form_pesquisar_produto.html">Voltar</a>