<?php	
	//conexao com o bd
	require('..\conexao.php');
		
	// Pegamos a palavra
	$id = $_POST['id'];
	
	$nome = $_POST['nome'];
	$lancamento = $_POST['lancamento'];
	$preco = $_POST['preco'];
	$faixa_etaria = $_POST['faixa_etaria'];
	$genero = $_POST['genero'];
	$plataforma = $_POST['plataforma'];
	$midia = $_POST['midia'];
	$imagem = $_POST['imagem'];
	//Procurando o produto solicitado
	$sql = mysqli_query($conn,"SELECT * FROM $table_produto `nome`='$nome' AND `lancamento`='$lancamento' AND `preco`='$preco' AND `faixa_etaria`='$faixa_etaria' AND `genero`='$genero' AND `plataforma`='$plataforma' AND `midia`='$midia' AND `imagem`='$imagem'");
	
	//Transformando o resultado em numeros
	$numero = mysqli_num_rows($sql);
		
	if($numero != 0)
	{
		echo "Nome existente";
	}
	else
	{	
		
		//Atualizando a tabela
		$sql2 = mysqli_query($conn,"UPDATE $table_produto SET `nome`='$nome',`lancamento`='$lancamento',`preco`='$preco',`faixa_etaria`='$faixa_etaria',`genero`='$genero',`plataforma`='$plataforma',`midia`='$midia',`imagem`='$imagem' WHERE `id` = $id");
		
		echo"Atualizado com Sucesso!";
	}		
?>
<p><a href="form_pesquisar_produto.html">Voltar</a>