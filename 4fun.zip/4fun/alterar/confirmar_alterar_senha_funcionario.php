<?php
	require('..\conexao.php');
	session_start();
	// Pegamos a palavra
	$login = $_SESSION["login"];
	$cargo = $_SESSION["cargo"];
    
    $sql = mysqli_query($conn,"SELECT * FROM $table_funcionario WHERE `login` = '$login'");
	
	//Transformando o resultado em numeros
	$numero = mysqli_num_rows($sql);
	
	//Transformando o resultado em vetor
	$vetor_funcionario = mysqli_fetch_array($sql);
$id = $_POST["id"];	
$senha = $_POST['senha'];
$senha = md5($senha);

$sql = mysqli_query($conn,"SELECT from $table_funcionario `senha` = '$senha' WHERE `id` = '$id'");
$sql2 = mysqli_query($conn,"UPDATE $table_funcionario SET `senha` = '$senha' WHERE `id` = '$id'");
if($cargo == 'A'){
?>	
	<script language='javascript'>
alert("Senha alterada com sucesso");
document.location.href="../adm.php";
	</script>
	<?php
}else{
	?>	
	<script language='javascript'>
alert("Senha alterada com sucesso");
document.location.href="../ti.php";
	</script>
	<?php
}